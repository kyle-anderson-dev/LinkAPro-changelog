<?php
/*****************************************************************************
*
*	copyright(c) - aonetheme.com - Service Finder Team
*	More Info: http://aonetheme.com/
*	Coder: Service Finder Team
*	Email: contact@aonetheme.com
*
******************************************************************************/
?>

<?php
$html = '<div class="col-md-4 col-sm-4  col-xs-6 equal-col">
		  <div class="sf-element-bx padding-lr-30">
			<div class="icon-bx-md rounded-bx"> <i class="fa '.esc_attr($a['fa_icon']).'"></i> </div>
			<h4>'.esc_html($a['title']).'</h4>
			<p>'.$content.'</p>
		  </div>
		</div>
		';
?>
<!-- Featured Providers Inner Start -->